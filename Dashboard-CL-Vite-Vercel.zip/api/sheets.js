import {handleSheets} from '../sheets.mjs';

// A resposta é transmitida em blocos para suportar abas maiores que 4,5 MB.
export function streamResponse(bytes,headers,status=200){
  let offset=0;
  const stream=new ReadableStream({pull(controller){
    if(offset>=bytes.length){controller.close();return}
    const end=Math.min(offset+65536,bytes.length);
    controller.enqueue(bytes.subarray(offset,end));offset=end;
  }});
  return new Response(stream,{status,headers});
}

export default {
  async fetch(request){
    const response=await handleSheets(request);
    if(!response.ok)return response;
    const bytes=new Uint8Array(await response.arrayBuffer());
    return streamResponse(bytes,response.headers,response.status);
  }
};
