import assert from 'node:assert/strict';
import {preview} from 'vite';
import fs from 'node:fs/promises';

const config=JSON.parse(await fs.readFile(new URL('../vercel.json',import.meta.url),'utf8'));
assert.equal(config.framework,'vite');
assert.equal(config.outputDirectory,'dist');
assert.equal(config.installCommand,'npm ci');

const server=await preview({preview:{host:'127.0.0.1',port:4174,strictPort:true,open:false}});
try{
  const base=server.resolvedUrls.local[0];
  const page=await fetch(base);
  assert.equal(page.status,200);
  const html=await page.text();
  assert.match(html,/<title>Dashboard CL/);
  assert.doesNotMatch(html,/src="\/app\.mjs"/);
  const assets=[...html.matchAll(/(?:src|href)="(\/assets\/[^\"]+)"/g)].map(m=>m[1]);
  assert.ok(assets.some(a=>a.endsWith('.js')),'Bundle JS não encontrado');
  assert.ok(assets.some(a=>a.endsWith('.css')),'CSS de produção não encontrado');
  for(const asset of assets){
    const response=await fetch(new URL(asset,base));
    assert.equal(response.status,200,asset);
    assert.ok((await response.text()).length>0,asset);
  }
  const get=await fetch(new URL('api/sheets',base));
  assert.equal(get.status,405);
  assert.match((await get.json()).error,/permitido/);
  const bad=await fetch(new URL('api/sheets',base),{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({sheet:'GERAL',url:'https://example.com/dados'})
  });
  assert.equal(bad.status,400);
  assert.match((await bad.json()).error,/docs\.google\.com/);
  console.log('Produção verificada: HTML, JS, CSS e API de planilhas respondem corretamente.');
}finally{
  await new Promise(resolve=>server.httpServer.close(resolve));
}
