// Mantém compatibilidade com o comando de build da primeira versão.
import {build} from 'vite';
await build();
