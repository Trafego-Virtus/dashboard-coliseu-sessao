import {defineConfig} from 'vite';
import {localSheetsApi} from './dev/local-api.mjs';

export default defineConfig({
  // A primeira versão gerava public/. Não copiar esses arquivos antigos.
  publicDir: false,
  plugins: [localSheetsApi()],
  build: {
    outDir: 'dist',
    target: 'es2022',
    sourcemap: false
  }
});
