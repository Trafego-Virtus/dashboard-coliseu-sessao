import {Readable} from 'node:stream';
import sheetsApi from '../api/sheets.js';

export function localSheetsApi(){
  const configure=server=>{
    server.middlewares.use('/api/sheets',async(req,res)=>{
      try{
        const chunks=[];
        let size=0;
        for await(const chunk of req){
          size+=chunk.length;
          if(size>8192){
            res.writeHead(413,{'Content-Type':'application/json'});
            res.end(JSON.stringify({error:'Pedido muito grande.'}));
            return;
          }
          chunks.push(chunk);
        }
        const method=req.method||'GET';
        const request=new Request('http://localhost/api/sheets',{
          method,
          headers:{'Content-Type':'application/json'},
          ...(!['GET','HEAD'].includes(method)?{body:Buffer.concat(chunks)}:{})
        });
        const response=await sheetsApi.fetch(request);
        res.writeHead(response.status,Object.fromEntries(response.headers));
        if(response.body){
          Readable.fromWeb(response.body).on('error',()=>res.destroy()).pipe(res);
        }else res.end();
      }catch{
        if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json'});
        res.end(JSON.stringify({error:'Não foi possível processar a fonte de dados.'}));
      }
    });
  };
  return {name:'dashboard-cl-local-sheets',configureServer:configure,configurePreviewServer:configure};
}
