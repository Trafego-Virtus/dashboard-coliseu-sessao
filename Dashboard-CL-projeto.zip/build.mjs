import fs from 'node:fs/promises';
const output=new URL('public/',import.meta.url);
await fs.mkdir(output,{recursive:true});
for(const file of ['index.html','style.css','core.mjs','app.mjs'])await fs.copyFile(new URL(file,import.meta.url),new URL(file,output));
console.log('Dashboard CL preparado para Vercel: public/ + api/sheets.js');
